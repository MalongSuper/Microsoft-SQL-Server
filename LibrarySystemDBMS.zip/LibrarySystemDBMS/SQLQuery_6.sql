USE Library;
GO

CREATE VIEW [View_Reader] AS
SELECT * FROM Reader;
GO

CREATE VIEW [View_BookCollection] AS
SELECT * FROM BookCollection;
GO

CREATE VIEW [View_Book] AS
SELECT * FROM Book;
GO

CREATE VIEW [View_Borrowed] AS
SELECT * FROM Borrowed;
GO